# How Make Games?

Página web educativa sobre creación de videojuegos.

## Archivos
- `index.html` — estructura y contenido.
- `style.css` — diseño y adaptación a celular.
- `script.js` — menú móvil y formulario.

## Publicar en GitHub Pages
1. Crea una cuenta en GitHub.
2. Crea un repositorio nuevo. Para una URL tipo `https://TUUSUARIO.github.io/`, el repositorio debe llamarse `TUUSUARIO.github.io`.
3. Sube `index.html`, `style.css` y `script.js`.
4. En el repositorio entra a **Settings → Pages**.
5. En **Build and deployment**, selecciona **Deploy from a branch**.
6. Elige la rama `main` y la carpeta `/ (root)`.
7. Guarda y espera unos minutos.
8. Abre `https://TUUSUARIO.github.io/`.

No necesitas comprar un dominio.
